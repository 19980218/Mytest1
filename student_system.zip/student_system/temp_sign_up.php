<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) ";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

$sql = "set names utf8";
@mysql_query($sql);
$user = $_POST['user_new'];
$pw = $_POST['pw_new'];
$name = $_POST['name_new'];
$sex = $_POST['sex'];
$sql = "insert into student(st_no,st_password,st_name,st_sex) value('$user','$pw','$name','$sex');";
//echo $sql;
$result = mysql_query($sql);
if ($result)
{
     echo "<script>confirm('注册成功')</script>";
     echo "<script>location='sign-in.php'</script>";
}
else
{
     echo "<script>confirm('注册失败')</script>";
     echo "<script>location='sign-up.php'</script>";
}
mysql_close();
?>