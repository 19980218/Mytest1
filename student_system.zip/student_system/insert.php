<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

    
$sql = "set names utf8";
@mysql_query($sql);
$user = $_POST['user5'];
$pr_name = $_POST['name5'];
$pw = $_POST['pw5'];
$sex = $_POST['sex5'];  
if (isset($_POST['identity3']))
{
     $identity = $_POST['identity3'];
     //echo $identity;
    if ($identity == 2)
    {
        $sql = "select * from teacher where tc_no='$user' and tc_name = '$pr_name';";
        $result = mysql_query($sql);
        if (mysql_num_rows($result) == 1)
        {
            echo "<script>(confirm('该用户已经存在')) </script>";
   
	        echo "<script>location='temp_insert.php'</script>";
        }
        else
        {
            $sql = "insert into teacher(tc_no,tc_password,tc_name,tc_sex) value('$user','$pw','$pr_name','$sex');";
            //echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>(confirm('增加成功')) </script>";
   
	         echo "<script>location='temp_insert.php'</script>";
            }
            else
            {
                echo "<script>(confirm('增加失败')) </script>";
   
	           echo "<script>location='temp_insert.php'</script>";
            }
        }
    }
    else
    {
        $sql = "select * from student where st_no='$user' and st_name = '$pr_name';";
        //echo $sql;
        $result = mysql_query($sql);
        if (mysql_num_rows($result) == 1)
        {
            echo "<script>(confirm('该用户已经存在')) </script>";
   
	        echo "<script>location='temp_insert.php'</script>";
        }
        else
        {
            $sql = "insert into student(st_no,st_password,st_name,st_sex) value('$user','$pw','$pr_name','$sex');";
            //echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>(confirm('增加成功')) </script>";
   
	        echo "<script>location='temp_insert.php'</script>";
            }
            else
            {
                echo "<script>(confirm('增加失败')) </script>";
   
	           echo "<script>location='temp_insert.php'</script>";
            }
        }
    }
    
}
else
{
     echo "<script>(confirm('请选择用户的身份')) </script>";
   
	echo "<script>location='temp_insert.php'</script>";
}


?>