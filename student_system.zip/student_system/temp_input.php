<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) ";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

$user = $_POST['user3'];
$pr_name = $_POST['pr_name3'];
$grade = $_POST['grade'];
$sql = "set names utf8";
@mysql_query($sql);

$sql = "select project.pr_id from st_project,project where st_project.pr_id = project.pr_id and st_project.st_no = '$user' and project.pr_name = '$pr_name';";

//echo $sql;
$result = mysql_query($sql);
if (@mysql_num_rows($result) < 1)
{
    echo "<script>confirm('没有这个学生的参赛记录')</script>";
     echo "<script>location='input_grade.php'</script>";
}
else
{
    
    
    
    session_start();
    $user1 = $_SESSION['user'];
    $sql = "select student.st_no,project.pr_id,project.pr_name from student, project, tc_project, st_project,teacher where tc_project.pr_id=project.pr_id and teacher.tc_id=tc_project.tc_id and teacher.tc_no='$user1' and st_project.pr_id=tc_project.pr_id and st_project.st_no=student.st_no;";
    $result = mysql_query($sql);
    $flag = 1;
    
    while($row = @mysql_fetch_row($result))
    {
        //print_r($row);   
        if ($user == $row[0] && $pr_name == $row[2])
        {
            $flag = 0;
        }
    }
    
    if ($flag == 0)
    {
        $sql = "select project.pr_id from st_project,project where st_project.pr_id = project.pr_id and st_project.st_no = '$user' and project.pr_name = '$pr_name';";

        $result = mysql_query($sql);
        $row = @mysql_fetch_row($result);
        $pr_id = $row[0];
        //echo $pr_id;
        $sql = "select * from grade where user = '$user' and pr_id = '$pr_id';";
        $result = mysql_query($sql);
        if (mysql_num_rows($result) == 1)
        {
            echo "<script>confirm('该学生成绩已经录入')</script>";
            echo "<script>location='input_grade.php'</script>";
        }
        else
        {
             $sql = "insert into grade(user,pr_id,grade) value('$user','$pr_id','$grade');";
            //echo $sql;
            if (mysql_query($sql))
            {
                echo "<script>confirm('成绩录入成功')</script>";
                echo "<script>location='input_grade.php'</script>";
            }
            else
            {
                echo "<script>confirm('成绩录入失败')</script>";
                echo "<script>location='input_grade.php'</script>";
            }
        }
    }
    else
    {
        echo "<script>confirm('你并不负责该项目')</script>";
        echo "<script>location='input_grade.php'</script>";
    }
    
    
   
    
}
/*$sql = "select * from user where user='$user';";
$result = mysql_query($sql);
if (mysql_num_rows($result) < 1)
{
    echo "<script>confirm('学号有误')</script>";
     echo "<script>location='input_grade.php'</script>";
}
else
{
    $sql = "select pr_id from project where pr_name='$pr_name';";
    $result = mysql_query($sql);
    if (mysql_num_rows($result) < 1)
    {
        echo "<script>confirm('项目名称有误')</script>";
         echo "<script>location='input_grade.php'</script>";
    }
    else
    {
        $row = mysql_num_rows($result);
        $pr_id = $row[0];
        $sql = "insert into grade(user,pr_id,grade) value('$user','$pr_id','$grade');";
        if (mysql_query($sql))
        {
            echo "<script>confirm('成绩录入成功')</script>";
            echo "<script>location='input_grade.php'</script>";
        }
        else
        {
            echo "<script>confirm('成绩录入失败')</script>";
            echo "<script>location='input_grade.php'</script>";
        }
    }
}*/
?>