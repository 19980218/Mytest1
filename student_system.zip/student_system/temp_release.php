<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) </script>";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

    
$sql = "set names utf8";
@mysql_query($sql);
$name = $_POST['pr_name7'];
$ad = $_POST['ad7'];
$tiem1 = $_POST['time1'];
$time2 = $_POST['time2'];

$sql = "select * from project where pr_name='$name';";
$result = mysql_query($sql);
if (mysql_num_rows($result) == 1)
{
    echo "<script>(confirm('该项目已经存在')) </script>";
   
	echo "<script>location='release.php'</script>";
}
else
{
    $sql = "insert into project(pr_name,dp_address,pr_start,pr_end) value('$name','$ad','$tiem1','$time2');";
    if (mysql_query($sql))
    {
        echo "<script>(confirm('发布成功')) </script>";
   
	   echo "<script>location='release.php'</script>";
    }
    else
    {
        echo "<script>(confirm('发布失败')) </script>";
   
	   echo "<script>location='release.php'</script>";
    }
}

?>