﻿<?php
session_start();
if (isset($_SESSION['user']))
{
    //echo $_SESSION['user'];
    //unset($_SESSION['user']);
    
}
else
{
    echo "<script>location='sign-in.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Bootstrap Admin</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
    
    <link rel="stylesheet" type="text/css" href="stylesheets/theme.css">
    <link rel="stylesheet" href="lib/font-awesome/css/font-awesome.css">

   
 <script src="lib/jquery-1.7.2.min.js" type="text/javascript"></script>
    <!-- Demo page code -->

    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
  </head>

  <!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
  <!--[if IE 7 ]> <body class="ie ie7 "> <![endif]-->
  <!--[if IE 8 ]> <body class="ie ie8 "> <![endif]-->
  <!--[if IE 9 ]> <body class="ie ie9 "> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
  <body class=""> 
  <!--<![endif]-->
    
    <div class="navbar">
        <div class="navbar-inner">
                <ul class="nav pull-right">
                    
                    <li><a  class="hidden-phone visible-tablet visible-desktop" role="button">普通用户</a></li>
                    <li id="fat-menu" class="dropdown">
                        <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
                          
                        </a>

                        <ul class="dropdown-menu">
                          
                          
                        </ul>
                    </li>
                    
                </ul>
                <a class="brand" href="index.html"><span class="first">学生</span> <span class="second">竞赛管理系统</span></a>
        </div>
    </div>
    


    
    <div class="sidebar-nav">
        <a href="#dashboard-menu" class="nav-header" data-toggle="collapse"><i class="icon-dashboard"></i>指示板</a>
        <ul id="dashboard-menu" class="nav nav-list collapse in">
            <li><a href="index.php">主页</a></li>
            <li ><a href="users.php">竞赛信息</a></li>
            <li ><a href="user.php">参赛报名</a></li>
            
            
        </ul>

        <a href="#accounts-menu" class="nav-header" data-toggle="collapse"><i class="icon-briefcase"></i>用户<span class="label label-info">+3</span></a>
        <ul id="accounts-menu" class="nav nav-list collapse">
            <li ><a href="sign-in.php">登录</a></li>
            <li ><a href="sign-up.php">注册</a></li>
            
        </ul>

       

       

        <a href="help.php" class="nav-header" ><i class="icon-question-sign"></i>成绩查询</a>
        
    </div>
    

    
    <div class="content">
        
        <div class="header">
          

            <h1 class="page-title">显示信息</h1>
        </div>
        
               

        <div class="container-fluid">
            <div class="row-fluid">
                    

<div class="row-fluid">

   

    <div class="block">
        <a href="#page-stats" class="block-heading" data-toggle="collapse">你好：</a>
        <div id="page-stats" class="block-body collapse in">

            <div class="stat-widget-container">
               

                <div class="stat-widget">
                    <div class="stat-button">
                        <p class="title">欢迎使用学生竞赛管理系统</p>
                        
                    </div>
                </div>

                

                

            </div>
        </div>
    </div>
</div>

<div class="row-fluid">
    <div class="block span6">
        <a href="#tablewidget" class="block-heading" data-toggle="collapse">近期比赛信息<span class="label label-warning">+10</span></a>
        <div id="tablewidget" class="block-body collapse in">
            <table class="table">
            <?php
                        $conn= @mysql_connect('localhost','root','');
                        
                        if($conn)
                        {
                        }	
                        else
                        {
                        	echo "<script>if(confirm('连接失败')) ";
                        	echo "<script>location='sign-in.php'</script>";
                        
                        }
                        
                        if(mysql_select_db('student_project', $conn))
                        {
                        }	
                        else
                            echo "<script>confirm('选择数据库失败')</script>";
                            
                        //$program_char = "utf8" ;
                        //@mysqli_set_charset( $conn , $program_char );
                        $sql = "set names utf8";
                        @mysql_query($sql);
                        $sql = "select pr_id,pr_name , pr_start,pr_end from project limit 3;";
                       $result = mysql_query($sql);
                        
                        
                        echo '<thead>
                                <tr>
                                  
                                  <th>项目编号</th>
                                  <th>项目名称</th>
                                  <th>开始时间</th>
                                  <th>结束时间</th>
                                </tr>
                              </thead>';
                              
                        echo '<tbody>';
                        while($row = mysql_fetch_row($result))
                        {
                          
                            echo '<tr>';
                                echo "<td>$row[0]</td>";
                                echo "<td>$row[1]</td>";
                                echo "<td>$row[2]</td>";
                                echo "<td>$row[3]</td>";
                            echo '</tr>';
                            
                        }
                          echo '</tbody>';
                        mysql_close();
                                 
            ?>
            <!--
              <thead>
                <tr>
                  <th>project_name</th>
                  <th>project_start</th>
                  <th>project_end</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>aa</td>
                  <td>aa</td>
                  <td>aa</td>
                </tr>
                <tr>
                  <td>aa</td>
                  <td>aa</td>
                  <td>aa</td>
                </tr>
                <tr>
                  <td>aa</td>
                  <td>aa</td>
                  <td>dd</td>
                </tr>
                
                
              </tbody>
              -->
            </table>
           
        </div>
    </div>
    <div class="block span6">
        <a href="#widget1container" class="block-heading" data-toggle="collapse">可下拉 </a>
        <div id="widget1container" class="block-body collapse in">
            <h2>参赛流程</h2>
            <p>This template was developed with <a href="http://middlemanapp.com/" target="_blank">Middleman</a> and includes .erb layouts and views.</p>
            <p>All of the views you see here (sign in, sign up, users, etc) are already split up so you don't have to waste your time doing it yourself!</p>
            <p>The layout.erb file includes the header, footer, and side navigation and all of the views are broken out into their own files.</p>
            <p>If you aren't using Ruby, there is also a set of plain HTML files for each page, just like you would expect.</p>
        </div>
    </div>
</div>

<div class="row-fluid">
   
    <div class="block span6">
        <p class="block-heading">不可下拉</p>
        <div class="block-body">
            <h2>关于我们</h2>
            <p>The CSS is built with Less. There is a compiled version included if you prefer plain CSS.</p>
            <p>Fava bean jícama seakale beetroot courgette shallot amaranth pea garbanzo carrot radicchio peanut leek pea sprouts arugula brussels sprout green bean. Spring onion broccoli chicory shallot winter purslane pumpkin gumbo cabbage squash beet greens lettuce celery. Gram zucchini swiss chard mustard burdock radish brussels sprout groundnut. Asparagus horseradish beet greens broccoli brussels.</p>
            <p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>
        </div>
    </div>
</div>


                    
                    <footer>
                        <hr>

                        
                       
                    </footer>
                    
            </div>
        </div>
    </div>
    
     <script src="lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>

    
    
  </body>
</html>


