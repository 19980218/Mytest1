<?php

$conn= @mysql_connect('localhost','root','');

if($conn)
{
}	
else
{
	echo "<script>if(confirm('连接失败')) ";
	echo "<script>location='sign-in.php'</script>";

}

if(mysql_select_db('student_project', $conn))
{
}	
else
    echo "<script>confirm('选择数据库失败')</script>";

session_start();
$usr = $_SESSION['user'];
$pr_id = $_POST['pr_id'];
$pr_name = $_POST['pr_name'];
$sql = "set names utf8";
@mysql_query($sql);
$sql = "select * from project where pr_id = '$pr_id' and pr_name = '$pr_name';";

//echo "<script>confirm('$sql')</script>";
     
$result = mysql_query($sql);
echo $sql;
if (mysql_num_rows($result) < 1)
{
    echo "<script>confirm('项目信息有误')</script>";
     echo "<script>location='user.php'</script>";
}
else
{
    $row = mysql_fetch_row($result);
    $pr_id = $row[0];
    
    $user = $_SESSION['user'];
    $sql = "select * from st_project where st_no = '$user' and pr_id = '$pr_id';";
    $result = mysql_query($sql);
    if (mysql_num_rows($result) == 1)
    {
        echo "<script>confirm('你已经报名该比赛')</script>";
        echo "<script>location='user.php'</script>";
    }
    else
    {
        
        $sql = "insert into st_project(st_no,pr_id) value('$user','$pr_id');";
       echo $sql;
        if ( mysql_query($sql))
        {
            echo "<script>confirm('报名成功')</script>";
             echo "<script>location='user.php'</script>";
        }
        else
        {
            echo "<script>confirm('报名失败')</script>";
             echo "<script>location='user.php'</script>";
        } 
    }
    
    
    
}

?>